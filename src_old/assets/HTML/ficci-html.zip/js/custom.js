$(".left-mobile-menu").click(function(){
 $(".menu-list").toggle();	
});